//___FILEHEADER___

import Courier

class ___FILEBASENAME___: CourierNotificationServiceExtension {

    //
    //         ^      ╔══════════════════════════════╗
    //       >' )     ║ You can override this class, ║
    //       ( ( \   <  but it is not recommended    ║
    //      mm''|\    ╚══════════════════════════════╝
    //

}
