//___FILEHEADER___

#import <UserNotifications/UserNotifications.h>

@interface ___FILEBASENAME___ : UNNotificationServiceExtension

@end
